<?php

defined('BASEPATH') OR exit('No direct script access allowed');
require FCPATH . 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('home_model');
    }

    public function index() {
		$data['title'] = 'Upload';
        $data['user'] = $this->db->get_where('user', ['username' => $this->session->userdata('username')])
            ->row_array();
		$this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/adddataexcel');
            $this->load->view('templates/footer');
        
    }

    public function spreadsheet_format_download() {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="template.xlsx"');

        $spreadsheet = new Spreadsheet();
        $sheet = $spreadsheet->getActiveSheet();
        $sheet->setCellValue('A1', 'ID');
        $sheet->setCellValue('B1', 'NAMA');
        $sheet->setCellValue('C1', 'NO WA');
        $sheet->setCellValue('D1', 'NAMA BISNIS');
        $sheet->setCellValue('E1', 'DOMAIN');
        $sheet->setCellValue('F1', 'KATEGORI');
        $sheet->setCellValue('G1', 'KONTRAK');
        $sheet->setCellValue('H1', 'STATUS');
        $sheet->setCellValue('I1', 'TGL PERPANJANG');
        $sheet->setCellValue('J1', 'NILAI');
        $sheet->setCellValue('K1', 'KETERANGAN');

        $writer = new Xlsx($spreadsheet);
        $writer->save("php://output");
    }

	public function spreadsheet_import() {
		$upload_file = $_FILES['upload_file']['name'];
		$extension = pathinfo($upload_file, PATHINFO_EXTENSION);
	
		if ($extension == 'csv') {
			$reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
		} else if ($extension == 'xls') {
			$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
		} else {
			$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
		}
	
		$spreadsheet = $reader->load($_FILES['upload_file']['tmp_name']);
		$sheetdata = $spreadsheet->getActiveSheet()->toArray();
		$sheetcount = count($sheetdata);
	
		if ($sheetcount > 1) {
			$data = array();
			for ($i = 1; $i < $sheetcount; $i++) {
				// Exclude 'id' or set it to NULL if it's auto-increment
				$data[] = array(
					// 'id' => $sheetdata[$i][0], // Exclude this line if 'id' is auto-increment
					'nama' => $sheetdata[$i][1],
					'no_wa' => $sheetdata[$i][2],
					'nama_bisnis' => $sheetdata[$i][3],
					'domain' => $sheetdata[$i][4],
					'kategori' => $sheetdata[$i][5],
					'kontrak' => $sheetdata[$i][6],
					'status' => $sheetdata[$i][7],
					'tgl_perpanjang' => $sheetdata[$i][8],
					'nilai' => $sheetdata[$i][9],
					'keterangan' => $sheetdata[$i][10],
				);
			}
	
			// Insert batch without 'id' to prevent duplicate primary key errors
			$insertdata = $this->home_model->insert_batch($data);
			if ($insertdata) {
				$this->session->set_flashdata('message', '<div class="alert alert-success">Successfully Added.</div>');
				redirect('home');
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-danger">Data Not uploaded. Please Try Again.</div>');
				redirect('home');
			}
		}
	}
	
}
