<?php
defined('BASEPATH') or exit('No direct script access allowed');

class List_model extends CI_Model
{
    // public function getDataclient()
    // {
    //     return $this->db->get('client_data')->result_array();
    // }
    public function getDataClient() {
        // Mengurutkan status "Aktif" terlebih dahulu, lalu data yang lebih lengkap
        $this->db->order_by("FIELD(status, 'Aktif') DESC");
        $this->db->order_by("
            ( 
                LENGTH(NULLIF(nama, '')) + 
                LENGTH(NULLIF(nama_bisnis, '')) + 
                LENGTH(NULLIF(domain, '')) + 
                LENGTH(NULLIF(kategori, '')) + 
                LENGTH(NULLIF(kontrak, '')) + 
                LENGTH(NULLIF(tgl_perpanjang, '')) + 
                LENGTH(NULLIF(nilai, '')) + 
                LENGTH(NULLIF(keterangan, ''))
            ) DESC, 
            tgl_perpanjang ASC
        ");
        $query = $this->db->get('client_data'); 
        return $query->result_array();
    }
    public function getDataclientById($id)
    {
        return $this->db->get_where('client_data', ['id' => $id])->row_array();
    }
    public function deleteClient($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('client_data');
    }
}
