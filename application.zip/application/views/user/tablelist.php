<div class="row">
    <div class="container">
        <div class="container-fluid card">
            <h1 class="h3 mb-4 mt-2 text-gray-800"><?= $title ?></h1>
            <?= $this->session->flashdata('message'); ?>
            <nav class="navbar navbar-inverse position-absolute top-0 end-0">
            </nav>
            <table class="table-bordered table table-hover text-center border shadow-sm p-3 mb-5 bg-white rounded">
                <tr>
                    <th class="bg-body-secondary" scope="col">id</th>
                    <th class="bg-body-secondary">Program Studi</th>
                    <th class="bg-body-secondary">Kode</th>
                    <th class="bg-body-secondary">Mata Kuliah</th>
                    <th class="bg-body-secondary">SKS</th>
                    <th class="bg-body-secondary">Deskripsi</th>
                    <th class="bg-body-secondary">Semester</th>
                    <th class="bg-body-secondary">Action</th>
                </tr>
                <tbody>
                    <?php $no = 1; ?>
                    <?php foreach ($datarps as $mhs) : ?>
                        <tr>
                            <td scope="row"><?= $no++; ?></td>
                            <td><?= $mhs['program_studi']; ?></td>
                            <td><?= $mhs['kode']; ?></td>
                            <td><?= $mhs['mata_kuliah']; ?></td>
                            <td><?= $mhs['sks']; ?></td>
                            <td><?= $mhs['deskripsi']; ?></td>
                            <td><?= $mhs['semester']; ?></td>
                            <td>
                                <a href="<?= base_url('user/editrps/') . $mhs['id_rps']; ?>" class="btn btn-warning" data-toggle="modal" data-target="#newSubMenuModal"><i class="bi bi-pencil-square"></i></a>
                                <a class="border btn btn-primary" href="<?= base_url('user/view/') . $mhs['id_rps']; ?>"><i class="bi bi-eye"></i>
                                </a>
                                <a class="border btn btn-success" href="<?= base_url('user/tablemateri/') . $mhs['id_rps']; ?>"><i class="bi bi-card-list"></i>
                                </a>
                                <a class="border btn btn-danger" href="<?= base_url('user/delete/') . $mhs['id_rps']; ?>" onclick="return confirm('Are you sure to delete this?')"><i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>

<!-- Modal -->
<div class="modal fade" id="newSubMenuModal" tabindex="-1" role="dialog" aria-labelledby="newSubMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog align-items-center justify-content-center" role="document">
        <div class="modal-content" style="width: 700px;">
            <div class="modal-header">
                <h5 class="modal-title" id="newSubMenuModalLabel">Edit RPS</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="content bg-white border shadow-sm p-3 mb-4 mt-3 bg-white rounded">
                    <ul class="nav nav-tabs mt-4">
                        <li class="nav-item">
                            <a class="nav-link border-end active" data-bs-toggle="tab" href="#head">Header RPS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border-end" data-bs-toggle="tab" href="#gambaran">Gambaran Umum</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border-end" data-bs-toggle="tab" href="#capaian">Capaian Pembelajaran</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border-end" data-bs-toggle="tab" href="#prasyarat">Prasyarat</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border-end" data-bs-toggle="tab" href="#unit">Unit Pembelajaran</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border-end" data-bs-toggle="tab" href="#aktivitas">Tugas/Aktivitas dan
                                Penilaian</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link border-end" data-bs-toggle="tab" href="#referensi">Referensi</a>
                        </li>
                    </ul>

                    <!-- body rps -->
                    <!-- Header RPS -->
                    <form action="<?= base_url('user/editrps/') . $mhs['id_rps']; ?>" method="post">
                        <div class="container tab-content mt-3">
                            <div class="row bg-light border tab-pane active" id="head">
                                <div class="form-row mx-2 my-2" style="">
                                    <div class="col-md-6">
                                        <label for="program_studi" class="form-label">Program Studi</label>
                                        <select name="program_studi" class="form-select">
                                            <option value="<?= $mhs['program_studi']; ?>"><?= $mhs['program_studi']; ?></option>
                                            <option value="Teknik Informatika">Teknik Informatika</option>
                                            <option value="Manajemen Informatika">Manajemen Informatika</option>
                                            <option value="Ilmu Komunikasi">Ilmu Komunikasi</option>
                                            <option value="Sistem Informasi">Sistem Informasi</option>
                                            <option value="Geografi">Geografi</option>
                                            <option value="Hubungan Internasional">Hubungan Internasional</option>
                                            <option value="Kewirausahaan">Kewirausahaan</option>
                                            <option value="Informatika">Informatika</option>
                                        </select>
                                    </div>
                                    <div class="col-6">
                                        <label for="kode" class="form-label">Kode Mata Kuliah</label>
                                        <input type="text" class="input form-control" name="kode" value="<?= $mhs['kode']; ?>">
                                    </div>
                                    <div class="col-6">
                                        <label for="mata_kuliah" class="form-label">Mata Kuliah</label>
                                        <input type="text" class="input form-control" name="mata_kuliah" value="<?= $mhs['mata_kuliah']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="semester" class="form-label">Semester</label>
                                        <select name="semester" class="form-select">
                                            <option selected><?= $mhs['semester']; ?></option>
                                            <option value="Ganjil">Ganjil</option>
                                            <option value="Genap">Genap</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="sks" class="form-label">Bobot SKS</label>
                                        <input type="text" class="input form-control" name="sks" value="<?= $mhs['sks']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="deskripsi" class="form-label">Deskripsi</label>
                                        <textarea name="deskripsi" class="input form-control"><?= $mhs['deskripsi']; ?></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col"><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- gambaran umum -->
                        <div class="container tab-content mt-3">
                            <div class="row bg-light border tab-pane" id="gambaran">
                                <div class="form-row mx-2 my-2">
                                    <div class="col">
                                        <label for="gambaran_umum" class="form-label">Gambaran Umum</label>
                                        <textarea name="gambaran_umum" class="input form-control"><?= $mhs['gambaran_umum']; ?></textarea>
                                    </div>


                                    <div class="row">
                                        <div class="col"><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Capaian Pembelajaran -->
                        <div class="container tab-content mt-3">
                            <div class="row bg-light border tab-pane" id="capaian">
                                <div class="form-row mx-2 my-2">
                                    <div class="col">
                                        <label for="capaian_pembelajaran" class="form-label">Capaian Pembelajaran</label>
                                        <textarea name="capaian_pembelajaran" class="input form-control"><?= $mhs['capaian_pembelajaran']; ?></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col"><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- prasyarat -->
                        <div class="container tab-content mt-3">
                            <div class="row bg-light border tab-pane" id="prasyarat">
                                <div class="form-row mx-2 my-2">
                                    <div class="col">
                                        <label for="prasyarat" class="form-label">Prasyarat dan Pengetahuan Awal</label>
                                        <textarea name="prasyarat" class="input form-control"><?= $mhs['prasyarat']; ?></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col"><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- unit pembelajaran -->
                        <div class="container tab-content mt-3">
                            <div class="row bg-light border tab-pane" id="unit">
                                <div class="form-row mx-2 my-2">
                                    <div class="col-6">
                                        <label for="kemampuan" class="form-label">Kemampuan Akhir yang Diharapkan</label>
                                        <textarea name="kemampuan" class="input form-control"><?= $mhs['kemampuan']; ?></textarea>
                                    </div>
                                    <div class="col-6">
                                        <label for="indikator" class="form-label">Indikator</label>
                                        <textarea name="indikator" class="input form-control"><?= $mhs['indikator']; ?></textarea>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="bahan_kajian" class="form-label">Bahan Kajian</label>
                                        <textarea name="bahan_kajian" class="input form-control"><?= $mhs['bahan_kajian']; ?></textarea>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="metode_pembelajaran" class="form-label">Metode Pembelajaran</label>
                                        <input type="text" class="input form-control" name="metode_pembelajaran" value="<?= $mhs['metode_pembelajaran']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="waktu" class="form-label">Waktu</label>
                                        <input type="text" class="input form-control" name="waktu" value="<?= $mhs['waktu']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="metode_penilaian" class="form-label">Metode Penilaian</label>
                                        <input type="text" class="input form-control" name="metode_penilaian" value="<?= $mhs['metode_penilaian']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="bahan_ajar" class="form-label">Bahan Ajar</label>
                                        <input type="text" class="input form-control" name="bahan_ajar" value="<?= $mhs['bahan_ajar']; ?>">
                                    </div>
                                    <div class="row">
                                        <div class="col"><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- tugas dan aktivitas -->
                        <div class="container tab-content mt-3">
                            <div class="row bg-light border tab-pane" id="aktivitas">
                                <div class="form-row mx-2 my-2">
                                    <div class="col-6">
                                        <label for="aktivitas" class="form-label">Tugas/Aktivitas</label>
                                        <textarea name="aktivitas" class="input form-control"><?= $mhs['aktivitas']; ?></textarea>
                                    </div>
                                    <div class="col-6">
                                        <label for="waktu_tugas" class="form-label">Waktu</label>
                                        <input type="text" class="input form-control" name="waktu_tugas" value="<?= $mhs['waktu_tugas']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="bobot" class="form-label">Bobot</label>
                                        <input type="text" class="input form-control" name="bobot" value="<?= $mhs['bobot']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="kriteria" class="form-label">Kriteria Penilaian</label>
                                        <input type="text" class="input form-control" name="kriteria" value="<?= $mhs['kriteria']; ?>">
                                    </div>
                                    <div class="col-md-6">
                                        <label for="indikator_penilaian" class="form-label">Indikator Penilaian</label>
                                        <textarea name="indikator_penilaian" class="input form-control"><?= $mhs['indikator_penilaian']; ?></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col"><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- referensi -->
                        <div class="container tab-content mt-3">
                            <div class="row bg-light border tab-pane" id="referensi">
                                <div class="form-row mx-2 my-2">
                                    <div class="col">
                                        <label for="referensi" class="form-label">Referensi</label>
                                        <textarea name="referensi" class="input form-control"><?= $mhs['referensi']; ?></textarea>
                                    </div>
                                    <div class="row">
                                        <div class="col"><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>