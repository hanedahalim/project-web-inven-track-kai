<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

<div class="card shadow mx-4">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-12 col-md-10">
                <h4 class="mb-0"><i class="fa fa-cubes"></i> Edit Data Client</h4>
            </div>
        </div>
        <hr class="mt-0" />
        <form method="post" action="<?= base_url('user/editdataclient/'.$datarps['id']); ?>">
            <div class="col-md-8">
                <div class="form-group row">
                    <label for="ClientID" class="col-sm-3 col-form-label">Client ID</label>
                    <div class="col-sm-9 col-md-6">
                        <input type="text" class="form-control form-control-sm <?= (form_error('id')) ? 'is-invalid' : ''; ?>" id="ClientID" required name="id" placeholder="Client ID" value="<?= $datarps['id']; ?>" readonly>
                        <div class="invalid-feedback">
                            <?= form_error('id', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="nama" class="col-sm-3 col-form-label">Nama</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control form-control-sm <?= (form_error('nama')) ? 'is-invalid' : ''; ?>" id="nama" name="nama" placeholder="Nama" value="<?= $datarps['nama']; ?>">
                        <div class="invalid-feedback">
                            <?= form_error('nama', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="no_wa" class="col-sm-3 col-form-label">No WA</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control form-control-sm <?= (form_error('no_wa')) ? 'is-invalid' : ''; ?>" id="no_wa" name="no_wa" placeholder="No WA" value="<?= $datarps['no_wa']; ?>">
                        <div class="invalid-feedback">
                            <?= form_error('no_wa', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="nama_bisnis" class="col-sm-3 col-form-label">Nama Bisnis</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control form-control-sm <?= (form_error('nama_bisnis')) ? 'is-invalid' : ''; ?>" id="nama_bisnis" name="nama_bisnis" placeholder="Nama Bisnis" value="<?= $datarps['nama_bisnis']; ?>">
                        <div class="invalid-feedback">
                            <?= form_error('nama_bisnis', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="domain" class="col-sm-3 col-form-label">Domain</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control form-control-sm <?= (form_error('domain')) ? 'is-invalid' : ''; ?>" id="domain" name="domain" placeholder="Domain" value="<?= $datarps['domain']; ?>">
                        <div class="invalid-feedback">
                            <?= form_error('domain', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="kategori" class="col-sm-3 col-form-label">Kategori</label>
                    <div class="col-sm-9">
                        <select name="kategori" class="form-control-sm form-select">
                            <option selected><?= $datarps['kategori']; ?></option>
                            <option value="Google Ads">Google Ads</option>
                            <option value="Facebook Ads">Facebook Ads</option>
                            <option value="Wordpress">Wordpress</option>
                        </select>
                        <div class="invalid-feedback">
                            <?= form_error('kategori', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="kontrak" class="col-sm-3 col-form-label">Kontrak</label>
                     <div class="col-sm-9">
                        <select name="kontrak" class="form-control-sm form-select">
                            <option selected><?= $datarps['kontrak']; ?> Bulan</option>
                            <option value="1">1 Bulan</option>
                            <option value="2">2 Bulan</option>
                            <option value="3">3 Bulan</option>
                            <option value="4">4 Bulan</option>
                            <option value="5">5 Bulan</option>
                            <option value="6">6 Bulan</option>
                            <option value="7">7 Bulan</option>
                            <option value="8">8 Bulan</option>
                            <option value="9">9 Bulan</option>
                            <option value="10">10 Bulan</option>
                            <option value="11">11 Bulan</option>
                            <option value="12">12 Bulan</option>
                        </select>
                        <div class="invalid-feedback">
                            <?= form_error('kategori', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
    <label for="status" class="col-sm-3 col-form-label">Status</label>
    <div class="col-sm-6">
        <div class="custom-control custom-radio">
            <input type="radio" class="custom-control-input <?= (form_error('status')) ? 'is-invalid' : ''; ?>" id="Aktif" name="status" value="Aktif" <?= ($datarps['status'] == 'Aktif') ? 'checked' : ''; ?>>
            <label class="custom-control-label" for="Aktif">Aktif</label>
        </div>
        <div class="custom-control custom-radio mb-3">
            <input type="radio" class="custom-control-input <?= (form_error('status')) ? 'is-invalid' : ''; ?>" id="Tidak" name="status" value="Tidak Aktif" <?= ($datarps['status'] == 'Tidak Aktif') ? 'checked' : ''; ?>>
            <label class="custom-control-label" for="Tidak">Tidak Aktif</label>
            <div class="invalid-feedback">
                <?= form_error('status', '<p class="error-message">', '</p>'); ?>
            </div>
        </div>
    </div>
</div>

                
                <div class="form-group row">
                    <label for="tgl_masuk" class="col-sm-3 col-form-label">Tanggal Masuk</label>
                    <div class="col-sm-9">
                        <input type="date" class="form-control form-control-sm <?= (form_error('tgl_masuk')) ? 'is-invalid' : ''; ?>" id="tgl_masuk" name="tgl_masuk" placeholder="Tanggal Masuk" value="<?= $datarps['tgl_masuk']; ?>" readonly>
                        <div class="invalid-feedback">
                            <?= form_error('tgl_masuk', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <label for="tgl_perpanjang" class="col-sm-3 col-form-label">Tanggal Perpanjang</label>
                    <div class="col-sm-9">
                        <input type="date" class="form-control form-control-sm <?= (form_error('tgl_perpanjang')) ? 'is-invalid' : ''; ?>" id="tgl_perpanjang" name="tgl_perpanjang" placeholder="Tanggal Perpanjang" value="<?= $datarps['tgl_perpanjang']; ?>">
                        <div class="invalid-feedback">
                            <?= form_error('tgl_perpanjang', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="nilai" class="col-sm-3 col-form-label">Nilai</label>
                    <div class="col-sm-9">
                        <input type="number" class="form-control form-control-sm <?= (form_error('nilai')) ? 'is-invalid' : ''; ?>" id="nilai" name="nilai" placeholder="Nilai" value="<?= $datarps['nilai']; ?>">
                        <div class="invalid-feedback">
                            <?= form_error('nilai', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
                    <label for="keterangan" class="col-sm-3 col-form-label">Keterangan</label>
                    <div class="col-sm-9">
                        <textarea class="form-control form-control-sm <?= (form_error('keterangan')) ? 'is-invalid' : ''; ?>" id="keterangan" name="keterangan" placeholder="Keterangan"><?= $datarps['keterangan']; ?></textarea>
                        <div class="invalid-feedback">
                            <?= form_error('keterangan', '<p class="error-message">', '</p>'); ?>
                        </div>
                    </div>
                </div>
                
                <div class="form-group row">
                    <div class="col-sm-9 offset-md-3">
                        <button type="submit" name="update" value="Update" class="btn btn-primary btn-sm">Update Data</button>
                        <button type="button" class="btn btn-light btn-sm" onclick="window.history.back()">Kembali</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>