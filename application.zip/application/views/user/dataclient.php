<div class="row">
    <div class="container">
        <div class="container-fluid card">
            <h1 class="h3 mb-4 mt-2 text-gray-800"><?= $title ?></h1>
            <nav class="navbar navbar-inverse position-absolute top-0 end-0">
                <div class="container-fluid" style="width:100%;">
                    <a href="<?= base_url('user/createclient'); ?>" class="btn btn-primary navbar-btn border mt-1" >Tambah Data</i></a>
                </div>
            </nav>
            <!-- Filter Kategori -->
            <div class="mb-3" style="width:20%;">
                <select id="filterKategori" class="fox form-select">
                    <option value="">Semua Kategori</option>
                    <option value="Google Ads">Google Ads</option>
                    <option value="Facebook Ads">Facebook Ads</option>
                    <option value="WordPress">WordPress</option>
                </select>
            </div>
            <!-- Tabel -->
            <div style="overflow-x: auto;">
                <table class="table table-responsive table-hover text-center border shadow-sm p-3 mb-5 bg-white rounded" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th class="bg-body-secondary text-center" scope="col">No</th>
                            <th class="bg-body-secondary text-center">Nama</th>
                            <th class="bg-body-secondary text-center">Nomor</th>
                            <th class="bg-body-secondary text-center">Nama Bisnis</th>
                            <th class="bg-body-secondary text-center">Domain</th>
                            <th class="bg-body-secondary text-center">Kategori</th>
                            <th class="bg-body-secondary text-center">Kontrak(/Bulan)</th>
                            <th class="bg-body-secondary text-center">Status</th>
                            <th class="bg-body-secondary text-center">Tanggal Masuk</th>
                            <th class="bg-body-secondary text-center">Tanggal Perpanjang</th>
                            <th class="bg-body-secondary text-center">Nilai(Rupiah)</th>
                            <th class="bg-body-secondary text-center">Keterangan</th>
                            <th class="bg-body-secondary text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = $this->uri->segment(3) + 1; ?>
                        <?php foreach ($datarps as $mat) : ?>
                            <tr>
                                <td scope="row"><?= $no++; ?></td>
                                <td><?= $mat['nama']; ?></td>
                                <td><a href="https://wa.me/<?= $mat['no_wa']; ?>" target="_blank"><?= $mat['no_wa']; ?></a></td>
                                <td><?= $mat['nama_bisnis']; ?></td>
                                <td><a href="https://<?= $mat['domain']; ?>"><?= $mat['domain']; ?></a></td>
                                <td><?= $mat['kategori']; ?></td>
                                <td><?= $mat['kontrak']; ?></td>
                                <td><b class="text-center <?php echo ($mat['status'] == 'Aktif') ? 'badge bg-success' : 'badge bg-danger'; ?>">
                                        <?= $mat['status']; ?></b>
                                </td>
                                <td><span class="badge badge-secondary"><?= $mat['tgl_perpanjang']; ?></span></td>
                                <td> <span class="badge badge-success"><?= $mat['tgl_perpanjang']; ?></span></td>
                                <td><?= $mat['nilai']; ?></td>
                                <td><?= $mat['keterangan']; ?></td>
                                <td>
                                    <a class="border btn btn-warning" href="<?= base_url('user/editdataclient/') . $mat['id']; ?>"><i class="bi bi-pencil-square"></i></a>
                                    <a class="border btn btn-danger btn-delete" href="#" data-id="<?= $mat['id']; ?>"><i class="bi bi-trash"></i></a>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
</div>
<!-- Toast Notifikasi -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div id="successToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
        <div class="d-flex">
            <div class="toast-body">
                Data berhasil dihapus.
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
</div>

<!-- Modal Konfirmasi Hapus -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus data ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Hapus</button>
            </div>
        </div>
    </div>
</div>


<!-- DataTables JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/numeral.js/2.0.6/numeral.min.js"></script>

<script>
    $(document).ready(function () {
        var table = $('#dataTable').DataTable({
            "paging": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "drawCallback": function (settings) {
                // Format kolom Nilai
                $('#dataTable tbody tr').each(function () {
                    var nilaiCell = $(this).find('td:eq(10)');
                    var nilaiText = nilaiCell.text().replace(/,/g, '');
                    var formattedValue = numeral(nilaiText).format('0,0');
                    nilaiCell.text(formattedValue);

                    // Pengecekan tanggal perpanjang
                    var tglPerpanjangCell = $(this).find('td:eq(9)');
                    var tglPerpanjangText = tglPerpanjangCell.text().trim();
                    var tglPerpanjangDate = new Date(tglPerpanjangText);
                    var today = new Date();

                    if (!isNaN(tglPerpanjangDate.getTime())) {
                        var timeDiff = tglPerpanjangDate - today;
                        var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

                        if (diffDays > 0 && diffDays <= 7) {
                            tglPerpanjangCell.find('span.badge').removeClass('badge-secondary').addClass('badge-warning');
                        } else if (diffDays < 0) {
                            tglPerpanjangCell.find('span.badge').removeClass('badge-secondary').addClass('badge-danger');
                        } else {
                            tglPerpanjangCell.find('span.badge').removeClass('badge-warning badge-danger').addClass('badge-secondary');
                        }
                    }
                });
            }
        });

        // Event listener untuk filter kategori
        $('#filterKategori').on('change', function () {
            var selectedCategory = $(this).val();
            table.column(5).search(selectedCategory).draw(); // Kolom ke-6 adalah kolom Kategori (indeks 5)
        });
    });
</script>
<script>
    $(document).ready(function () {
        let deleteId;

        // Event saat tombol hapus diklik
        $('.btn-delete').on('click', function (e) {
            e.preventDefault();
            deleteId = $(this).data('id'); // Simpan ID data
            $('#deleteModal').modal('show'); // Tampilkan modal konfirmasi
        });

        // Event saat konfirmasi hapus diklik
        $('#confirmDelete').on('click', function () {
            $.ajax({
                url: '<?= base_url('user/deleteClient/'); ?>' + deleteId,
                type: 'POST',
                success: function (response) {
                    $('#deleteModal').modal('hide'); // Tutup modal
                    $('#successToast').toast('show'); // Tampilkan notifikasi
                    // Refresh tabel setelah penghapusan
                    setTimeout(function () {
                        location.reload();
                    }, 1000);
                },
                error: function () {
                    alert('Terjadi kesalahan saat menghapus data.');
                }
            });
        });
    });
</script>

